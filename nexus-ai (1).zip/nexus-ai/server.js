import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PUBLIC = path.join(__dirname, 'public');
const FALLBACK = path.join(__dirname, 'models-fallback.json');
function loadDotEnv(){
  try{
    const txt=fs.readFileSync(path.join(__dirname,'.env'),'utf8');
    for(const line of txt.split(/\r?\n/)){const m=line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);if(m && process.env[m[1]]===undefined)process.env[m[1]]=m[2].replace(/^['\"]|['\"]$/g,'');}
  }catch{}
}
loadDotEnv();
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.XKIRO_API_KEY;
const BASE = 'https://api.xkiro.com';

const MIME = {
  '.html':'text/html; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.css':'text/css; charset=utf-8',
  '.json':'application/json; charset=utf-8', '.svg':'image/svg+xml', '.png':'image/png', '.jpg':'image/jpeg',
  '.jpeg':'image/jpeg', '.webp':'image/webp', '.ico':'image/x-icon'
};

function send(res, status, body, type='application/json; charset=utf-8') {
  res.writeHead(status, {'Content-Type': type, 'Cache-Control':'no-store'});
  res.end(body);
}
function sendJson(res, status, value) { send(res, status, JSON.stringify(value)); }
function requireKey(res) {
  if (!API_KEY) { sendJson(res, 500, {error:'Nexus AI is not configured. Add XKIRO_API_KEY to .env and restart.'}); return false; }
  return true;
}
async function readBody(req, limit=18*1024*1024) {
  const chunks=[]; let size=0;
  for await (const chunk of req) { size += chunk.length; if(size>limit) throw new Error('Request body is too large.'); chunks.push(chunk); }
  return Buffer.concat(chunks);
}
async function xkiro(pathname, init={}) {
  const headers = new Headers(init.headers || {});
  headers.set('Authorization', `Bearer ${API_KEY}`);
  return fetch(BASE + pathname, {...init, headers});
}
function fallbackModels(){ try { return JSON.parse(fs.readFileSync(FALLBACK,'utf8')); } catch { return []; } }

async function handleApi(req,res,url){
  if(req.method==='GET' && url.pathname==='/api/models'){
    try { const r=await fetch(BASE+'/v1/models'); const t=await r.text(); res.writeHead(r.status,{'Content-Type':r.headers.get('content-type')||'application/json','Cache-Control':'no-store'}); return res.end(t); }
    catch(e){ return sendJson(res,503,{error:e.message}); }
  }
  if(req.method==='GET' && url.pathname==='/api/models/all'){
    try { const r=await fetch(BASE+'/v1/models?modality=all'); const t=await r.text(); if(r.ok){res.writeHead(r.status,{'Content-Type':r.headers.get('content-type')||'application/json','Cache-Control':'no-store'}); return res.end(t);} }
    catch{}
    return sendJson(res,200,{data:fallbackModels(),source:'fallback'});
  }
  if(req.method==='POST' && url.pathname==='/api/chat'){
    if(!requireKey(res)) return;
    try{
      const raw=await readBody(req); const body=JSON.parse(raw.toString('utf8'));
      if(!body.model || !Array.isArray(body.messages)) return sendJson(res,400,{error:'model and messages are required.'});
      const payload={model:body.model,messages:body.messages,stream:true};
      if(typeof body.temperature==='number')payload.temperature=body.temperature;
      if(typeof body.max_tokens==='number')payload.max_tokens=body.max_tokens;
      if(body.reasoning_effort)payload.reasoning_effort=body.reasoning_effort;
      const r=await xkiro('/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
      res.writeHead(r.status,{'Content-Type':r.headers.get('content-type')||'text/event-stream','Cache-Control':'no-cache, no-transform','Connection':'keep-alive'});
      if(!r.body) return res.end();
      const reader=r.body.getReader();
      while(true){const {value,done}=await reader.read();if(done)break;res.write(value);}
      return res.end();
    }catch(e){return sendJson(res,502,{error:e.message});}
  }
  if(req.method==='GET' && url.pathname==='/api/usage'){
    if(!requireKey(res))return;
    try{const r=await xkiro('/v1/usage');const t=await r.text();res.writeHead(r.status,{'Content-Type':r.headers.get('content-type')||'application/json','Cache-Control':'no-store'});return res.end(t)}catch(e){return sendJson(res,502,{error:e.message})}
  }
  if(req.method==='POST' && url.pathname==='/api/image/generate'){
    if(!requireKey(res))return;
    try{const body=JSON.parse((await readBody(req)).toString('utf8'));if(!body.model||!body.prompt)return sendJson(res,400,{error:'model and prompt are required.'});const r=await xkiro('/v1/images/generations',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model:body.model,prompt:body.prompt,n:1,size:body.size||'1024x1024',...(body.style?{style:body.style}:{})})});const t=await r.text();res.writeHead(r.status,{'Content-Type':r.headers.get('content-type')||'application/json','Cache-Control':'no-store'});return res.end(t)}catch(e){return sendJson(res,502,{error:e.message})}
  }
  if(req.method==='GET' && url.pathname.startsWith('/api/image/job/')){
    if(!requireKey(res))return;
    const id=decodeURIComponent(url.pathname.slice('/api/image/job/'.length));
    try{const r=await xkiro('/v1/images/generations/'+encodeURIComponent(id));const t=await r.text();res.writeHead(r.status,{'Content-Type':r.headers.get('content-type')||'application/json','Cache-Control':'no-store'});return res.end(t)}catch(e){return sendJson(res,502,{error:e.message})}
  }
  return false;
}

const server=http.createServer(async (req,res)=>{
  try{
    const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
    if(url.pathname.startsWith('/api/')){const handled=await handleApi(req,res,url);if(handled!==false)return;return sendJson(res,404,{error:'Not found'});}
    let filePath=path.normalize(path.join(PUBLIC,url.pathname==='/'?'index.html':url.pathname));
    if(!filePath.startsWith(PUBLIC))return sendJson(res,403,{error:'Forbidden'});
    try{const st=fs.statSync(filePath);if(st.isDirectory())filePath=path.join(filePath,'index.html');}catch{filePath=path.join(PUBLIC,'index.html');}
    if(!fs.existsSync(filePath))filePath=path.join(PUBLIC,'index.html');
    const ext=path.extname(filePath).toLowerCase();res.writeHead(200,{'Content-Type':MIME[ext]||'application/octet-stream'});fs.createReadStream(filePath).pipe(res);
  }catch(e){if(!res.headersSent)sendJson(res,500,{error:e.message});else res.end();}
});

server.listen(PORT,()=>{console.log(`Nexus AI running at http://localhost:${PORT}`);if(!API_KEY)console.warn('XKIRO_API_KEY is not set. Add it to .env before using chat/image generation.');});
