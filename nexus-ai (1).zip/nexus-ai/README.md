# Nexus AI

A small self-hosted multi-model AI chat app powered by xKiro.

## Features

- Nexus AI branded web chat UI
- Live xKiro model catalog with provider/model picker
- Switch models at any time, including mid-conversation
- Streaming responses
- Image uploads for vision-capable models
- Text/code/markdown/CSV/JSON attachments
- Local chat history in the browser sidebar
- Search, delete, and start new chats
- xKiro usage panel
- Image Studio using xKiro's image generation API
- Server-side API key proxy so the xKiro key is not exposed to browser JavaScript

## Setup

1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Put your NEW xKiro API key in `.env` as `XKIRO_API_KEY=...`.
4. Run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

Do not commit `.env` to Git.

## Security

The xKiro key must remain on the server. Rotate the key that was posted in chat before deploying.

## Deployment

This app can run on Render, Railway, Fly.io, a VPS, or another Node host. Set `XKIRO_API_KEY` as a server environment variable and expose port 3000 (or the platform-provided port).
